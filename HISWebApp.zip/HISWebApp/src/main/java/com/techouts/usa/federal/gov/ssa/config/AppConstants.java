package com.techouts.usa.federal.gov.ssa.config;

import org.springframework.context.annotation.Configuration;

/**
 * It's used to configure all String values with String Constants
 * @author  Amol Paydalwar
 *
 */

@Configuration
public class AppConstants {

	
	public static final String MSGSUCC="msgSucc";
	public static final String MSGFAIL="msgFail";
	
	public static final String SSN_DTLS_FORM ="SSNDtls";
	public static final String MSG ="msg";
	public static final String LIST_SSNMODELS ="ssnModels";
	public static final String RESTVALUE ="SsnRestController";

	public static final String LIST_STATES ="states";
	public static final String MALE ="male";
	public static final String FEMALE ="female";
	public static final String GENDERS ="genders"; 
}
