package com.techouts.usa.federal.gov.ssa.model;

import lombok.Data;

@Data
public class StatesModel {
	
	private int id;
	private String stateCode;
	private String stateName;
	


}
 
