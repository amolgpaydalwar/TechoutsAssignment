package com.techouts.usa.federal.gov.ssa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HisWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(HisWebAppApplication.class, args);
	}

}
