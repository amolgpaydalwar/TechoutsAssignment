package com.techouts.usa.federal.gov.ssa.exception;

@SuppressWarnings("serial")
public class InvalidSsnIdException extends RuntimeException {

	public InvalidSsnIdException(String msg) {
		super(msg);
	}
}
