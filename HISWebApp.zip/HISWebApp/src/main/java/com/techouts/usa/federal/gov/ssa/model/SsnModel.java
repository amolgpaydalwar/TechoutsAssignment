package com.techouts.usa.federal.gov.ssa.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class SsnModel {
	private long ssnId;
	private String fname;
	private String lname;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dob;
	private String gender;
	private long phNo;
	private String state;
	private MultipartFile photo;
}