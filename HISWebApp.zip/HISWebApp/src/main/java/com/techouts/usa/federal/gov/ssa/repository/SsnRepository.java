package com.techouts.usa.federal.gov.ssa.repository;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.techouts.usa.federal.gov.ssa.entity.SsnMasterEntity;


@Repository("SSNDtlsRepo")
public interface SsnRepository extends JpaRepository<SsnMasterEntity, Serializable> {

}
