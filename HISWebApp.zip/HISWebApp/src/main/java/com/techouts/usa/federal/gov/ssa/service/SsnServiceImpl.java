package com.techouts.usa.federal.gov.ssa.service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.techouts.usa.federal.gov.ssa.entity.SsnMasterEntity;
import com.techouts.usa.federal.gov.ssa.entity.StatesMasterEntity;
import com.techouts.usa.federal.gov.ssa.exception.InvalidSsnIdException;
import com.techouts.usa.federal.gov.ssa.model.SsnModel;
import com.techouts.usa.federal.gov.ssa.model.StatesModel;
import com.techouts.usa.federal.gov.ssa.repository.SsnRepository;
import com.techouts.usa.federal.gov.ssa.repository.StatesRepository;


/**
 * this class is used to collect data from repository and 
 * returns model object to controller 
 * @author  
 *
 */



@Service
public class SsnServiceImpl implements SsnService 
{
	@Autowired
	private StatesRepository StateRepo;
	@Autowired
	private SsnRepository  ssnRepo;
	
	
	@Override
	public List<StatesModel> getAllStates() {
	 
		List<StatesMasterEntity> entities=null;
		List<StatesModel> statelist=new ArrayList<>();
		// use repo to get all states
		entities=StateRepo.findAll();
		// convert entities to models
		entities.forEach(entity->{
			StatesModel model=new StatesModel();
			
			BeanUtils.copyProperties(entity, model);
			statelist.add(model);
		});
		
		return statelist;
	}

	@Override
	public Long inserSSNDtls(SsnModel ssnModel) throws IOException {
		 SsnMasterEntity ssnEntity=null;
		 
		// convert model to entity
			ssnEntity = new SsnMasterEntity();
			MultipartFile file;
			byte[] byteArr = ssnModel.getPhoto().getBytes();
			InputStream inputStream = new ByteArrayInputStream(byteArr);
			ssnEntity.setPhoto(byteArr);
			BeanUtils.copyProperties(ssnModel, ssnEntity);
			// use ssnRepo
			ssnEntity = ssnRepo.save(ssnEntity);
			return ssnEntity.getSsnId();
		}

	@Override
	public List<SsnModel> getAllSSNDtls() {
		 
		List<SsnMasterEntity> entities = null;
		List<SsnModel> ssnModels = new ArrayList<>();
		
		// use ssnRepo
				entities = ssnRepo.findAll();
				// convert entities to model
				entities.forEach(entity -> {
					SsnModel ssnModel = new SsnModel();
					byte[] bytes=entity.getPhoto();
					/*MultipartFile file=new MultipartFile() {
					
					@Override
					public void transferTo(File dest) throws IOException, IllegalStateException {
						
						dest.
					}
					
					@Override
					public boolean isEmpty() {
						// TODO Auto-generated method stub
						return false;
					}
					
					@Override
					public long getSize() {
						// TODO Auto-generated method stub
						return 0;
					}
					
					@Override
					public String getOriginalFilename() {
						// TODO Auto-generated method stub
						return null;
					}
					
					@Override
					public String getName() {
						// TODO Auto-generated method stub
						return null;
					}
					
					@Override
					public InputStream getInputStream() throws IOException {
						// TODO Auto-generated method stub
						return null;
					}
					
					@Override
					public String getContentType() {
						// TODO Auto-generated method stub
						return null;
					}
					
					@Override
					public byte[] getBytes() throws IOException {
						// TODO Auto-generated method stub
						return null;
					}
				};
				*/
					
					BeanUtils.copyProperties(entity, ssnModel);
					ssnModels.add(ssnModel);
				});
				return ssnModels;
			 
	}

	 
	@Override
	public SsnModel getStateByssnId(Long ssnId) {
		Optional<SsnMasterEntity> optional = null;
		SsnMasterEntity entity = null;
		SsnModel ssnModel = null;
		// use repository
		optional = ssnRepo.findById(ssnId);
		if (optional.isPresent()) {
			// get entity object
			entity = optional.get();
			// convert entity to model
			ssnModel = new SsnModel();
			BeanUtils.copyProperties(entity, ssnModel);
			return ssnModel;
		}
		// System.out.println(USARepo.findStates());
		else {
			throw new InvalidSsnIdException("Given SSN Id not registerd");
		}

	}// method

}
