package com.techouts.usa.federal.gov.ssa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="STATE")
public class StatesMasterEntity {
	
	@Id
	
	@Column(name="ID")
	private int id;
	@Column(name="CODE")
	private String stateCode;
	@Column(name="NAME")
	private String stateName;
	


}
