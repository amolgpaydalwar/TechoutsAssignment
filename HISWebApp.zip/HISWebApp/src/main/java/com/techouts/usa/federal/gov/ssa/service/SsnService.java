package com.techouts.usa.federal.gov.ssa.service;

import java.io.IOException;
import java.util.List;

import com.techouts.usa.federal.gov.ssa.model.SsnModel;
import com.techouts.usa.federal.gov.ssa.model.StatesModel;

public interface SsnService {
	
	public List<StatesModel> getAllStates();
	
	public Long inserSSNDtls(SsnModel ssnmodel)throws IOException;
	
	public List<SsnModel> getAllSSNDtls();
	
	public SsnModel getStateByssnId(Long ssnId);

}
