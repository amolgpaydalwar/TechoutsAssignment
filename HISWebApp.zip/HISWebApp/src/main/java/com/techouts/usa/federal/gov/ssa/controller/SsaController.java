package com.techouts.usa.federal.gov.ssa.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.techouts.usa.federal.gov.ssa.config.AppConstants;
import com.techouts.usa.federal.gov.ssa.config.AppProperties;
import com.techouts.usa.federal.gov.ssa.model.SsnModel;
import com.techouts.usa.federal.gov.ssa.model.StatesModel;
 import com.techouts.usa.federal.gov.ssa.service.SsnService;
import com.techouts.usa.federal.gov.ssa.service.SsnServiceImpl;

@Controller
public class SsaController {

	@Autowired
	private SsnService ssnService;

	@Autowired
	private AppProperties properties;


	/**
	 * this method is dispaly the form page with ssn dtls
	 * 
	 * @param model
	 * @return String as a logical view name
	 */
	@GetMapping(value = "/form")
	public String ShowSsnForm(Model model) {
		model.addAttribute(AppConstants.SSN_DTLS_FORM, new SsnModel());
		initializeFormValues(model);
		return "ssnRegisterForm";
	}

	/**
	 * this method collecting the result in form binding object
	 * 
	 * @param ssnModel
	 * @param attributes
	 * @return String redircting the request to get mode request
	 */
	@PostMapping(value="/register")
	public String registerSSNData(@ModelAttribute("SSNDtls") SsnModel ssnModel,RedirectAttributes attributes) {
		long ssnId=0;		
		System.out.println(ssnModel);
		//use ssnService
		try {
		ssnId=ssnService.inserSSNDtls(ssnModel);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		if(ssnId!=0) {
			attributes.addFlashAttribute(AppConstants.MSG, properties.getProperties().get(AppConstants.MSGSUCC)+ssnId);
		}
		return "redirect:/form";
	}
	
	/**
	 * @param model
	 * @return
	 */
	@GetMapping(value="getAllSSNRecords")
	public String getAllSSNDetails(Model model) {
		List<SsnModel> ssnModels=null;
		//use service
		ssnModels=ssnService.getAllSSNDtls();
		model.addAttribute(AppConstants.LIST_SSNMODELS,ssnModels);
		return "result";
	}
	
	
	/**
	 * this method is used to initialize form values
	 * 
	 * @param model
	 */
	private void initializeFormValues(Model model) {
		List<String> states=null;
		states=getStates();
		//add all states to model attribute
		model.addAttribute( AppConstants.LIST_STATES, states);

		//adding genders
		List<String> genders=new ArrayList<>();
		genders.add(properties.getProperties().get(AppConstants.MALE));
		genders.add(properties.getProperties().get(AppConstants.FEMALE));
		model.addAttribute(AppConstants.GENDERS, genders);
	}
	
	/**
	 * @return List<String> as a all state names
	 */
	private List<String> getStates(){
		List<StatesModel> stateslist=null;
		List<String> states=new ArrayList<>();
		//use service
				stateslist=ssnService.getAllStates();
				stateslist.forEach(st->{
					//get Each state name from model
				String stateName=st.getStateName();
				states.add(stateName);
				});	
				return states;
	}

}
