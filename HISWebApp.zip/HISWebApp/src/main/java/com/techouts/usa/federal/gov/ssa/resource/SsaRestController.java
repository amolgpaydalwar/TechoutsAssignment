package com.techouts.usa.federal.gov.ssa.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.techouts.usa.federal.gov.ssa.model.SsnModel;
import com.techouts.usa.federal.gov.ssa.service.SsnService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

 

/**
 * this class is used to provide rest services to client based on ssnId
 * 
 * @author  
 *
 */

@RestController
@RequestMapping("/ssnRest")
@Api(value = "SsnRestController", description = "this class is provides ssn Details")
public class SsaRestController {
	
	/**
	 * Ssa service is injected
	 */
	
	@Autowired
	SsnService service;
	
	/**
	 * this method is giving state name to client based on ssn Id
	 * 
	 * @param ssnId
	 * @return stateName
	 */
	
	@ApiOperation(value = "View a state based on given ssnId", response = String.class)
	@ApiResponses(value = { 
			@ApiResponse(code = 200, message = "Successfully retrieved list"),
			@ApiResponse(code = 401, message = "You are not authorized to view the resource"),
			@ApiResponse(code = 403, message = "Accessing the resource you were trying to reach is forbidden"),
			@ApiResponse(code = 404, message = "The resource you were trying to reach is not found") })
	
	
	@GetMapping(value = "/ssnState", produces = { "application/json", "application/xml" })
	public String getStateBySsn(@RequestParam("ssnId") Long ssnId) {
		SsnModel ssnModel = null;
		// use service
		ssnModel = service.getStateByssnId(ssnId);
		return ssnModel.getState();
	}


}
