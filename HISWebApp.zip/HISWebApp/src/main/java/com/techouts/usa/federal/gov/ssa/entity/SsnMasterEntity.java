package com.techouts.usa.federal.gov.ssa.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="SSN_MASTER")
public class SsnMasterEntity {
	
	@Id
	@GeneratedValue(generator="seq1",strategy=GenerationType.SEQUENCE)
	
	  @SequenceGenerator(name="seq1",sequenceName="SSN_IDSEQ",initialValue= 987654321,allocationSize=1)
	 
	@Column(name="SSN_ID")
	private long ssnId;
	@Column(name="FNAME")
	private String fname;
	@Column(name="LNAME")
	private String lname;
	@Column(name="DOB")
	private Date dob;
	@Column(name="GENDER")
	private String gender;
	@Column(name="PHNO")
	private long phNo;
	@Column(name="STATE")
	private String states;
	@Lob
	@Column(name="IMAGE")
	private byte[] photo;
}


